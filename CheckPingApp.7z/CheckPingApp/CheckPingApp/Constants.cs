﻿
namespace CheckPingApp
{
    public class Constants
    {
        public const string Log = "Log";
        public const string Error = "Error";
        public const string ProblemMessage = "בעיית חיבור לתחנה, נא לבדוק";
        public const string Station = "התחנה אליה ניגשת לא מחוברת";
    }
}
